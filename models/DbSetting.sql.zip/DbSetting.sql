/**************************
* 	 WEB PROGARAMMING     *
* MINI PROJECT DATABASE   *
* 	 by Nam Ho Cheol      *
* 	date: 2018.10.01      *
* email: nhc616@gmail.com *
*    kakaoID: nhc616      *
**************************/

# Create Schema for project
DROP DATABASE IF EXISTS `web_mini_project`;
CREATE DATABASE `web_mini_project`;

USE `web_mini_project`;

# create user table for manage users data
DROP TABLE IF EXISTS `web_mini_project`.`user`;
CREATE TABLE `web_mini_project`.`user` (
  `id` VARCHAR(20) NOT NULL,
  `password` VARCHAR(20) NOT NULL,
  `nickname` VARCHAR(45) NOT NULL,
  `name` VARCHAR(45) NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `id_UNIQUE` (`id` ASC),
  UNIQUE INDEX `nickname_UNIQUE` (`nickname` ASC));


# create store table for save OnlineBookStore data
DROP TABLE IF EXISTS `web_mini_project`.`store`;
CREATE TABLE `web_mini_project`.`store` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`));


# create book_info table for manage book data
DROP TABLE IF EXISTS `web_mini_project`.`book_info`;
CREATE TABLE `web_mini_project`.`book_info` (
  `ISBN` INT NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `author` VARCHAR(80) NOT NULL,
  `translator` VARCHAR(45) NULL,
  `publisher` VARCHAR(45) NOT NULL,
  `pub_date` DATE NOT NULL,
  `Org_Price` INT NULL,
  `img_link` VARCHAR(100) NULL,
  PRIMARY KEY (`ISBN`),
  UNIQUE INDEX `ISBN_UNIQUE` (`ISBN` ASC));
  

# create books table for save BookData for each stores
DROP TABLE IF EXISTS `web_mini_project`.`books`;
CREATE TABLE `web_mini_project`.`books` (
  `ISBN` INT NOT NULL,
  `store_id` INT NOT NULL,
  `price` INT NOT NULL,
  `link` VARCHAR(150) NOT NULL,
  PRIMARY KEY (`ISBN`, `store_id`),
  INDEX `FK_STOR_ID_BOOKS_idx` (`store_id` ASC),
  CONSTRAINT `FK_ISBN_BOOKS`
    FOREIGN KEY (`ISBN`) REFERENCES `web_mini_project`.`book_info` (`ISBN`)
		ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_STOR_ID_BOOKS`
    FOREIGN KEY (`store_id`) REFERENCES `web_mini_project`.`store` (`id`)
		ON DELETE CASCADE ON UPDATE CASCADE);


# create rank table for save BestSeller Data
DROP TABLE IF EXISTS `web_mini_project`.`rank`;
CREATE TABLE `web_mini_project`.`rank` (
  `week` DATE NOT NULL,
  `store_id` INT NOT NULL,
  `rank01` INT,`rank02` INT,`rank03` INT,
  `rank04` INT,`rank05` INT,`rank06` INT,
  `rank07` INT,`rank08` INT,`rank09` INT,
  `rank10` INT,`rank11` INT,`rank12` INT,
  `rank13` INT,`rank14` INT,`rank15` INT,
  PRIMARY KEY (`week`, `store_id`),
  CONSTRAINT `FK_STOR_ID_RANK`
	FOREIGN KEY (`store_id`) REFERENCES `web_mini_project`.`store` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ISBN_RANK01`
	FOREIGN KEY (`rank01`) REFERENCES `web_mini_project`.`book_info` (`ISBN`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ISBN_RANK02`
	FOREIGN KEY (`rank02`) REFERENCES `web_mini_project`.`book_info` (`ISBN`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ISBN_RANK03`
	FOREIGN KEY (`rank03`) REFERENCES `web_mini_project`.`book_info` (`ISBN`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ISBN_RANK04`
	FOREIGN KEY (`rank04`) REFERENCES `web_mini_project`.`book_info` (`ISBN`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ISBN_RANK05`
	FOREIGN KEY (`rank05`) REFERENCES `web_mini_project`.`book_info` (`ISBN`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ISBN_RANK06`
	FOREIGN KEY (`rank06`) REFERENCES `web_mini_project`.`book_info` (`ISBN`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ISBN_RANK07`
	FOREIGN KEY (`rank07`) REFERENCES `web_mini_project`.`book_info` (`ISBN`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ISBN_RANK08`
	FOREIGN KEY (`rank08`) REFERENCES `web_mini_project`.`book_info` (`ISBN`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ISBN_RANK09`
	FOREIGN KEY (`rank09`) REFERENCES `web_mini_project`.`book_info` (`ISBN`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ISBN_RANK10`
	FOREIGN KEY (`rank10`) REFERENCES `web_mini_project`.`book_info` (`ISBN`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ISBN_RANK11`
	FOREIGN KEY (`rank11`) REFERENCES `web_mini_project`.`book_info` (`ISBN`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ISBN_RANK12`
	FOREIGN KEY (`rank12`) REFERENCES `web_mini_project`.`book_info` (`ISBN`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ISBN_RANK13`
	FOREIGN KEY (`rank13`) REFERENCES `web_mini_project`.`book_info` (`ISBN`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ISBN_RANK14`
	FOREIGN KEY (`rank14`) REFERENCES `web_mini_project`.`book_info` (`ISBN`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ISBN_RANK15`
	FOREIGN KEY (`rank15`) REFERENCES `web_mini_project`.`book_info` (`ISBN`)
    ON DELETE CASCADE ON UPDATE CASCADE
);

        
        
# create our_comment table for manage comment from our webSite
DROP TABLE IF EXISTS `web_mini_project`.`our_comment`;
CREATE TABLE `web_mini_project`.`our_comment` (
  `no` INT NOT NULL AUTO_INCREMENT,
  `id` VARCHAR(20) NOT NULL,
  `ISBN` INT NOT NULL,
  `rate` FLOAT NOT NULL,
  `comment` VARCHAR(600) NOT NULL,
  `time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`no`),
  INDEX `FK_ID_idx` (`id` ASC),
  INDEX `FK_ISBN_CMT_OUR_idx` (`ISBN` ASC),
  CONSTRAINT `FK_ID_CMT_OUR`
    FOREIGN KEY (`id`) REFERENCES `web_mini_project`.`user` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ISBN_CMT_OUR`
    FOREIGN KEY (`ISBN`) REFERENCES `web_mini_project`.`book_info` (`ISBN`)
    ON DELETE CASCADE ON UPDATE CASCADE);
    
    
# create our_comment table for manage comment from other webSite
DROP TABLE IF EXISTS `web_mini_project`.`other_comment`;
CREATE TABLE `web_mini_project`.`other_comment` (
  `no` INT NOT NULL AUTO_INCREMENT,
  `id` VARCHAR(20) NOT NULL,
  `pubid` INT NOT NULL,
  `ISBN` INT NOT NULL,
  `rate` FLOAT NOT NULL,
  `comment` VARCHAR(600) NOT NULL,
  `time` DATETIME NOT NULL,
  PRIMARY KEY (`no`),
  INDEX `FK_STOR_ID_CMT_OTHER_idx` (`pubid` ASC),
  INDEX `FK_ISBN_CMT_OTHER_idx` (`ISBN` ASC),
  CONSTRAINT `FK_STOR_ID_CMT_OTHER`
    FOREIGN KEY (`pubid`) REFERENCES `web_mini_project`.`store` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ISBN_CMT_OTHER`
    FOREIGN KEY (`ISBN`) REFERENCES `web_mini_project`.`book_info` (`ISBN`)
    ON DELETE CASCADE ON UPDATE CASCADE);

